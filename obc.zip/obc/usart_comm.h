#ifndef __USART_COMM_H__
#define __USART_COMM_H__


#include "bsp_usart.h"

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"

#include "stm32f4xx.h"
#include <stdint.h>

#define UART4_DMA_CLK				RCC_AHB1Periph_DMA1
#define UART4_DMA_STREAM			DMA1_Stream4
#define UART4_DMA_CHANEL			DMA_Channel_4

#define USART6_DMA_CLK				RCC_AHB1Periph_DMA2
#define USART6_DMA_STREAM			DMA2_Stream6
#define USART6_DMA_CHANEL			DMA_Channel_5


#define GCS_DMA_CLK				USART6_DMA_CLK
#define GCS_DMA_STREAM			USART6_DMA_STREAM
#define GCS_DMA_CHANEL			USART6_DMA_CHANEL

#define SerialPORT USART6

#define GCS_DR_ADDR	    		(&SerialPORT->DR)//UART8_BASE+0x04

#define GCS_BUF_SIZE			255



void task_gcs(void *pvParameters __attribute__((unused)));

void usart_send_hk(uint8_t *str,uint8_t len);
void GCS_Usart_init(uint32_t baudrate);




#endif
