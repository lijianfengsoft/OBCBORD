
#include "ADCScomIF.h"
#include "usart_comm.h"
#include "cubesat.h"
#include "cube_com.h"

#include "bsp_pca9665.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "semphr.h"

#include "stm32f4xx.h"
#include "stm32f4xx_dma.h"

#include <string.h>


void GCS_send_result(void);
void GCS_USART_IRQ(struct USART_TypeDefStruct *pUSART);
void GCS_DMA_normal_Config(uint8_t length);
void GCS_DMA_ReConfig(uint8_t length);

uint8_t generate_frame(void);

void GCSUsartIrq(void);
void UsartRxDell_GCS(uint8_t recdata, struct USART_TypeDefStruct *pUSART);

//
uint8_t GCS_send[256] = {0};
//

struct USART_TypeDefStruct GCS_Usart;

uint8_t GCS_receive[100]={0};
uint8_t GCS_rec_length = 0;
uint8_t rec_data = 0,rec_state = 0,is_rec = 0;

void task_gcs(void *pvParameters __attribute__((unused))){

	portTickType xLastWakeTime = xTaskGetTickCount();

	while (1) {

		if(is_rec)
			{
				switch(GCS_receive[5]){
				case 1:
					CubeUnPacket(&GCS_receive[5]);
					break;
				case 2:
					i2c_master_transaction(OBC_TO_ADCS_HANDLE, ADCS_I2C_ADDR,
							&GCS_receive[5], GCS_receive[4]-8, NULL, 0, 1000);
					break;
				}

				is_rec = 0;
			}
			vTaskDelayUntil(&xLastWakeTime, (50/ portTICK_RATE_MS));
		}
}


void usart_send_hk(uint8_t *str,uint8_t len){

	memcpy(GCS_send,str,len);

	GCS_DMA_normal_Config(len);

	DMA_Cmd(GCS_DMA_STREAM, ENABLE);//enable

}

void GCS_Usart_init(uint32_t baudrate) {


	GCS_Usart.ComPort = GCS;
	GCS_Usart.BaudRate = baudrate;

	GCS_Usart.pFuncRxDataIrq = UsartRxDell_GCS;
	GCS_Usart.pUsartIrq = GCSUsartIrq;

	USART_CreatComPort(&GCS_Usart);
}


void GCS_DMA_normal_Config(uint8_t length)
{
    DMA_InitTypeDef DMA_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;


	DMA_DeInit(GCS_DMA_STREAM);

	RCC_AHB1PeriphClockCmd(GCS_DMA_CLK, ENABLE);//enable DMA clk

	DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;//memory to pyh
	DMA_InitStructure.DMA_BufferSize = (uint32_t)length;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//pep addr not incre
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;			//memory addr incre
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//pep data size 1byte
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;// memory data size 1byte
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//loop mode
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;//

	DMA_InitStructure.DMA_FIFOMode = 		DMA_FIFOMode_Disable;//
	DMA_InitStructure.DMA_FIFOThreshold = 	DMA_FIFOThreshold_HalfFull; //

	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//

	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)GCS_send; //


	DMA_InitStructure.DMA_Channel = GCS_DMA_CHANEL;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)GCS_DR_ADDR; //

	DMA_Init(GCS_DMA_STREAM, &DMA_InitStructure);//init

	USART_DMACmd(SerialPORT, USART_DMAReq_Tx, ENABLE);



	 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

	  /* Enable the UART5 RX DMA Interrupt */
//	  NVIC_InitStructure.NVIC_IRQChannel = DMA1_Stream4_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannel = DMA2_Stream6_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 6;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);

	  /* Enable DMA Stream Transfer Complete interrupt */
	  DMA_ITConfig(GCS_DMA_STREAM, DMA_IT_TC, ENABLE);

}



void GCS_DMA_ReConfig(uint8_t length)
{
    DMA_InitTypeDef DMA_InitStructure;

	DMA_InitStructure.DMA_BufferSize = (uint32_t)length;

	DMA_Init(GCS_DMA_STREAM, &DMA_InitStructure);//init

}

void DMA2_Stream6_IRQHandler(void){

  if (DMA_GetITStatus(DMA2_Stream6, DMA_IT_TCIF6))
  {
	  DMA_ClearITPendingBit(DMA2_Stream6, DMA_IT_TCIF6);
	  DMA_Cmd(GCS_DMA_STREAM, DISABLE);//enable
  }
}

void DMA1_Stream4_IRQHandler(void){

  if (DMA_GetITStatus(DMA1_Stream4, DMA_IT_TCIF4))
  {
	  DMA_ClearITPendingBit(DMA1_Stream4, DMA_IT_TCIF4);
	  DMA_Cmd(GCS_DMA_STREAM, DISABLE);//enable
  }
}


void GCSUsartIrq(void) {
	GCS_USART_IRQ(&GCS_Usart);
}

void GCS_USART_IRQ(struct USART_TypeDefStruct *pUSART){
	uint8_t _rxData;

//	if (USART_GetITStatus(UART4, USART_IT_ORE) != RESET) {
//		USART_ClearFlag(UART4, USART_FLAG_ORE);
//	}

	if (USART_GetITStatus(SerialPORT, USART_IT_RXNE) != RESET) {
		//判断读寄存器是否非空
		_rxData = (uint8_t) (USART_ReceiveData(SerialPORT) & 0xff);

		pUSART->pFuncRxDataIrq(_rxData & 0xff, pUSART);  // 接收数据送到处理函数中

		USART_ClearITPendingBit(SerialPORT, USART_IT_RXNE);
	}



}


void GCS_send_result(void){

	uint8_t length = 0;

	length = generate_frame();

	GCS_DMA_normal_Config(length);
//
	DMA_Cmd(GCS_DMA_STREAM, ENABLE);//enable

}



void UsartRxDell_GCS(uint8_t recdata, struct USART_TypeDefStruct *pUSART) {

	rec_data = recdata;
	switch (rec_state)
	{
		case 0:
			GCS_rec_length = 0;
			GCS_receive[GCS_rec_length++] = recdata;

			if ((recdata == 0x03))
			{
				rec_state = 1;
			}

			break;

		case 1:
			GCS_receive[GCS_rec_length++] = recdata;
			if ((recdata == 0xA4))
			{
				rec_state = 2;
			}
			else
			{
				rec_state = 0;
			}

			break;
		case 2:
			GCS_receive[GCS_rec_length++] = recdata;

			if ((GCS_rec_length >= GCS_receive[4])
					&& (GCS_rec_length>8))// be sure the frame is received over
			{
				is_rec = 1;

				rec_state = 0;
			}
			break;

		default:
			break;
	}
}



