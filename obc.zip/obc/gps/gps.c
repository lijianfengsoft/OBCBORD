/*
 * gps.c
 *
 *  Created on: 2016年5月12日
 *      Author: Administrator
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "qb50/globalavr_adcs.h"

#include "stm32f4xx.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "semphr.h"

#include "driver_debug.h"

#include "cubesat.h"
#include "switches.h"
#include "clock.h"

#include "gps.h"

gps_u gps_buffer1;
gps_u gps_buffer2;
char * valid_ptr = NULL;
char * current_ptr = gps_buffer1.str;
char * prev_ptr = NULL;

uint8_t gpsrcnt;
gps_u  gps_info;
uint16_t time_cnt;

/* GPS绾犻敊 */
uint16_t gps_wait = 0;
uint8_t gps_use;	//0 for GPSA ,1 for GPSB

void GPS_Init(void) {
	GPS_USARTDMA_Config();
	GPS_USART_Init();
}

void GPS_USARTDMA_Config(void)
{
    DMA_InitTypeDef DMA_InitStructure;

	RCC_AHB1PeriphClockCmd(GPSA_DMA_CLK | GPSB_DMA_CLK, ENABLE);//开启DMA时钟

	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;//外设到内存
	DMA_InitStructure.DMA_BufferSize = GPS_BUFFER_SIZE; //缓冲大小
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;//外设地址不增
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;//内存地址增
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据大小1byte
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;//内存数据大小1byte
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//循环模式
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;//优先级高
	DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;// 不开fifo
	DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull; //
	DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;//
	DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;//
	DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)current_ptr; //内存地址

	DMA_InitStructure.DMA_Channel = GPSA_DMA_CHANEL;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)GPSA_DR_ADDR; //外设地址为

	DMA_Init(GPSA_DMA_STREAM, &DMA_InitStructure);//初始化dma2 流
	DMA_Cmd(GPSA_DMA_STREAM, ENABLE);//开启dma2流

	DMA_InitStructure.DMA_Channel = GPSB_DMA_CHANEL;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)GPSB_DR_ADDR; //外设地址为

	DMA_Init(GPSB_DMA_STREAM, &DMA_InitStructure);//初始化dma2 流
	DMA_Cmd(GPSB_DMA_STREAM, ENABLE);//开启dma2流
}

void GPS_USART_Init(void)
{
    GPIO_InitTypeDef 	GPIO_InitStructure;
    NVIC_InitTypeDef   	NVIC_InitStructure;
    USART_InitTypeDef 	USART_InitStructure;

    /* Enable GPIO clock */
    RCC_AHB1PeriphClockCmd(GPSA_TX_PORTCLK | GPSA_RX_PORTCLK | GPSB_TX_PORTCLK | GPSB_RX_PORTCLK, ENABLE);
    /* Enable UART clock */
    RCC_APB2PeriphClockCmd(GPSA_SCLK | GPSB_SCLK, ENABLE);
    /* Connect PXx to USARTx_Tx*/
    GPIO_PinAFConfig(GPSA_TX_PORT, GPSA_TX_SOURCE, GPSA_TX_AF);
    GPIO_PinAFConfig(GPSB_TX_PORT, GPSB_TX_SOURCE, GPSB_TX_AF);
    /* Connect PXx to USARTx_Rx*/
    GPIO_PinAFConfig(GPSA_RX_PORT, GPSA_RX_SOURCE, GPSA_RX_AF);
    GPIO_PinAFConfig(GPSB_RX_PORT, GPSB_RX_SOURCE, GPSB_RX_AF);
    /* Configure USART Tx as alternate function  */
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Pin = GPSA_TX_PIN;
    GPIO_Init(GPSA_TX_PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPSB_TX_PIN;
    GPIO_Init(GPSB_TX_PORT, &GPIO_InitStructure);
    /* Configure USART Rx as alternate function  */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;

    GPIO_InitStructure.GPIO_Pin = GPSA_RX_PIN;
    GPIO_Init(GPSA_RX_PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPSB_RX_PIN;
    GPIO_Init(GPSB_RX_PORT, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx;
    /* USART configuration */
    USART_Init(GPSA_PORT_NAME, &USART_InitStructure);
    USART_Init(GPSB_PORT_NAME, &USART_InitStructure);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

    NVIC_InitStructure.NVIC_IRQChannel = GPSA_ISR_CHANEL;
    NVIC_Init(&NVIC_InitStructure);
    NVIC_InitStructure.NVIC_IRQChannel = GPSB_ISR_CHANEL;
    NVIC_Init(&NVIC_InitStructure);

    USART_ITConfig(GPSA_PORT_NAME, USART_IT_IDLE, ENABLE);
    /* Enable USART */
    USART_Cmd(GPSA_PORT_NAME, ENABLE);

    USART_ITConfig(GPSB_PORT_NAME, USART_IT_IDLE, ENABLE);
    /* Enable USART */
    USART_Cmd(GPSB_PORT_NAME, ENABLE);
}

void GPSA_ISR_HANDLER(void)
{
    u16 Data_Len;

    if(USART_GetITStatus(GPSA_PORT_NAME, USART_IT_IDLE) != RESET)//如果为空闲总线中断
    {
    	Data_Len = USART1->SR;
    	Data_Len = USART1->DR;

    	Data_Len = 0;

        USART_ClearITPendingBit(GPSA_PORT_NAME, USART_IT_IDLE);

        DMA_Cmd(GPSA_DMA_STREAM, DISABLE);//关闭DMA,防止处理其间有数据

        Data_Len = GPS_BUFFER_SIZE - DMA_GetCurrDataCounter(GPSA_DMA_STREAM);
        driver_debug(DEBUG_GPS,"Data_Len=%d\n\r",Data_Len);

        prev_ptr = current_ptr;
        valid_ptr = prev_ptr;

        current_ptr = (current_ptr == gps_buffer1.str ? gps_buffer2.str : gps_buffer1.str);

        GPS_Rx_Process();

        /* Write to DMAy Streamx NDTR register */
        GPSA_DMA_STREAM->NDTR = GPS_BUFFER_SIZE;
        /* Write to DMAy Streamx M0AR */
        GPSA_DMA_STREAM->M0AR = (uint32_t)current_ptr;

        DMA_Cmd(GPSA_DMA_STREAM, ENABLE);//开启DMA
    }
}

//void GPSB_ISR_HANDLER(void)
//{
//    u16 Data_Len;
//
//    if(USART_GetITStatus(GPSB_PORT_NAME, USART_IT_IDLE) != RESET)//如果为空闲总线中断
//    {
//        Data_Len = USART1->SR;
//        Data_Len = USART1->DR;
//
//		  Data_Len = 0;
//
//        USART_ClearITPendingBit(GPSB_PORT_NAME, USART_IT_IDLE);
//
//        DMA_Cmd(GPSB_DMA_STREAM, DISABLE);//关闭DMA,防止处理其间有数据
//
//        Data_Len = GPS_BUFFER_SIZE - DMA_GetCurrDataCounter(GPSB_DMA_STREAM);
//        driver_debug(DEBUG_GPS,"Data_Len=%d\n\r",Data_Len);
//
//        prev_ptr = current_ptr;
//        valid_ptr = prev_ptr;
//
//        current_ptr = (current_ptr == gps_buffer1.str ? gps_buffer2.str : gps_buffer1.str);
//
//        GPS_Rx_Process();
//
//        /* Write to DMAy Streamx NDTR register */
//        GPSB_DMA_STREAM->NDTR = GPS_BUFFER_SIZE;
//        /* Write to DMAy Streamx M0AR */
//        GPSB_DMA_STREAM->M0AR = current_ptr;
//
//        DMA_Cmd(GPSB_DMA_STREAM, ENABLE);//开启DMA
//    }
//}

int GPS_Rx_Process(void)
{
	unsigned char kc = 0,kj = 0;
	unsigned char str_tmp[82];
	unsigned char checksum = 0;
	double ret = 0.0;

	for(kc = 0;kc<gpsrcnt;kc++)
	{
		if((valid_ptr[kc] == 0x05)&&(valid_ptr[kc+1] == 0x0A)&&(valid_ptr[kc+2] == 0x3C))
		{
			for(kj = 0;kj<82;kj++)
				str_tmp[kj] = valid_ptr[kc+2+kj];
			break;
		}
		else
			continue;
	}

	if(kc == gpsrcnt) return 0;

	//cal checksum
	for(kc = 0;kc<80;kc++){
		checksum += str_tmp[kc];
		//checksum = checksum^str_tmp[kc];  //^寮傛垨
	}

	if(checksum == str_tmp[80])
	{
		gps_info.str[0] = str_tmp[0];		//head 0x3C
		gps_info.str[1] = str_tmp[1];		//length 0x4E
		gps_info.str[2] = str_tmp[2];		//status 0x00 or 0x0F

		/* weeks num */
		for(kc=0;kc<2;kc++){
			gps_info.str[3+kc] = str_tmp[4-kc];
		}

		/* seconds */
		for(kc=0;kc<8;kc++){
			gps_info.str[5+kc] = str_tmp[12-kc];
		}

		gps_info.str[13] = str_tmp[13];		//satenum

		/* PDOP */
		for(kc=0;kc<2;kc++){
			gps_info.str[14+kc] = str_tmp[15-kc];
		}

		/* X */
		for(kc=0;kc<8;kc++){
			gps_info.str[16+kc] = str_tmp[23-kc];
		}
		/* Y */
		for(kc=0;kc<8;kc++){
			gps_info.str[24+kc] = str_tmp[31-kc];
		}
		/* Z */
		for(kc=0;kc<8;kc++){
			gps_info.str[32+kc] = str_tmp[39-kc];
		}

		/* Vx */
		for(kc=0;kc<8;kc++){
			gps_info.str[40+kc] = str_tmp[47-kc];
		}
		/* Vy */
		for(kc=0;kc<8;kc++){
			gps_info.str[48+kc] = str_tmp[55-kc];
		}
		/* Vz */
		for(kc=0;kc<8;kc++){
			gps_info.str[56+kc] = str_tmp[63-kc];
		}

		/* GPS 閽熷樊 閽熸紓 */
		for(kc=0;kc<4;kc++){
			gps_info.str[64+kc] = str_tmp[67-kc];
		}
		for(kc=0;kc<4;kc++){
			gps_info.str[68+kc] = str_tmp[71-kc];
		}

		/* BD 閽熷樊 閽熸紓 */
		for(kc=0;kc<4;kc++){
			gps_info.str[72+kc] = str_tmp[75-kc];
		}
		for(kc=0;kc<4;kc++){
			gps_info.str[76+kc] = str_tmp[79-kc];
		}

		gps_info.str[80] = str_tmp[80];
		gps_info.str[81] = str_tmp[81];

		ret = sqrt(gps_info.velo[0]*gps_info.velo[0]+gps_info.velo[1]*gps_info.velo[1]+gps_info.velo[2]*gps_info.velo[2]);
		if((gps_info.status==0x00) && (ret<9000&&ret>6000))
		{
			AdcsGpsUse = VALID;
			gps_wait = 0;

			//娆℃暟鍒拌揪鏃舵墠鏍℃椂锛岀涓�娆′竴瀹氭牎鏃�
			if(time_cnt == 0 || time_cnt == 600)
			{
				time_t tt;

				tt = ((uint32_t)(gps_info.secs))+gps_info.weeks*7*86400+315964800+GPS_TIME_OFFSET;
				driver_debug(DEBUG_GPS,"GPS time is: %s\r\n", ctime(&tt));
				timesync(tt);
				updateTimeFlag = VALID;
				time_cnt = 0;
			}
			time_cnt++;
		}
	}

	return 0;
}

void GPS_Detection(void){
	/* GPS绾犻敊浠ｇ爜 */
	if(gps_wait >= 1800 ){
		gps_wait = 0;

		if(gps_use == GPS_USE_A){
			enable_gpsb();
		}

		if(gps_use == GPS_USE_B){
			enable_gpsa();
		}
	}
	gps_wait++;
	/***************/
}




