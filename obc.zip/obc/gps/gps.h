/*
 * gps.h
 *
 *  Created on: 2016年5月12日
 *      Author: Administrator
 */

#ifndef CONTRL_GPS_H_
#define CONTRL_GPS_H_

#define GPS_USE_A				0
#define GPS_USE_B				1
#define GPS_BUFFER_SIZE			100
#define GPS_TIME_OFFSET			(-16)

#define GPSA_ISR_HANDLER		USART1_IRQHandler
#define GPSA_ISR_CHANEL		 	USART1_IRQn
#define GPSA_PORT_NAME			USART1
#define GPSA_TX_PORT          	GPIOB
#define GPSA_RX_PORT          	GPIOB
#define GPSA_TX_PORTCLK       	RCC_AHB1Periph_GPIOB
#define GPSA_RX_PORTCLK       	RCC_AHB1Periph_GPIOB
#define GPSA_SCLK				RCC_APB2Periph_USART1
#define GPSA_RX_PIN          	GPIO_Pin_7
#define GPSA_TX_PIN          	GPIO_Pin_6
#define GPSA_EXTI_IRQn     		USART1_IRQn
#define GPSA_TX_AF         		GPIO_AF_USART1
#define GPSA_TX_SOURCE     		GPIO_PinSource6
#define GPSA_RX_AF         		GPIO_AF_USART1
#define GPSA_RX_SOURCE     		GPIO_PinSource7
#define GPSA_DMA_CLK			RCC_AHB1Periph_DMA2
#define GPSA_DMA_STREAM			DMA2_Stream5
#define GPSA_DMA_CHANEL			DMA_Channel_4
#define GPSA_DR_ADDR	    	(0x40011000+0x04)

#define GPSB_ISR_HANDLER		USART6_IRQHandler
#define GPSB_ISR_CHANEL		 	USART6_IRQn
#define GPSB_PORT_NAME			USART6
#define GPSB_TX_PORT          	GPIOC
#define GPSB_RX_PORT          	GPIOC
#define GPSB_TX_PORTCLK       	RCC_AHB1Periph_GPIOC
#define GPSB_RX_PORTCLK       	RCC_AHB1Periph_GPIOC
#define GPSB_SCLK				RCC_APB2Periph_USART6
#define GPSB_RX_PIN          	GPIO_Pin_7
#define GPSB_TX_PIN          	GPIO_Pin_6
#define GPSB_EXTI_IRQn     		USART6_IRQn
#define GPSB_TX_AF         		GPIO_AF_USART6
#define GPSB_TX_SOURCE     		GPIO_PinSource6
#define GPSB_RX_AF         		GPIO_AF_USART6
#define GPSB_RX_SOURCE     		GPIO_PinSource7
#define GPSB_DMA_CLK			RCC_AHB1Periph_DMA2
#define GPSB_DMA_STREAM			DMA2_Stream1
#define GPSB_DMA_CHANEL			DMA_Channel_5
#define GPSB_DR_ADDR	    	(0x40011400+0x04)

typedef union
{
	 char str[78];
	 struct __attribute__((packed))
	 {
	 	unsigned char 			status;
	 	unsigned short int 		weeks;   	//week
	 	double 					secs;		     	//sec
	 	unsigned char 			numV;		 //obs star number
	 	unsigned short int  	pdop;	     //pdop
	 	double 					posi[3];
	 	double 					velo[3];

	 	float 					gps_clock_1;
	 	float 					gps_clock_2;

	 	float 					bd_clock_1;
	 	float 					bd_clock_2;
	 };
}gps_u;

void GPS_Init(void);
void GPS_USARTDMA_Config(void);
void GPS_USART_Init(void);
int GPS_Rx_Process(void);

#endif /* CONTRL_GPS_H_ */
